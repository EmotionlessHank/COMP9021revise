import sys
from itertools import compress
def get_primes(n):
    sieve = bytearray([True])*(n//2)
    for i in range(3,int(n**0.5)+1,2):
        if sieve[i//2]:
            sieve[i*i//2::i] = bytearray((n-i*i-1)//(2*i)+1)
    return [2,*compress(range(3,n,2),sieve[1:])]
def f(a, b):
    '''
    The prime numbers between 2 and 12 (both included) are: 2, 3, 5, 7, 11
    The gaps between successive primes are: 0, 1, 1, 3.
    Hence the maximum gap is 3.
    
    Won't be tested for b greater than 10_000_000
    
    >>> f(3, 3)
    The maximum gap between successive prime numbers in that interval is 0
    >>> f(3, 4)
    The maximum gap between successive prime numbers in that interval is 0
    >>> f(3, 5)
    The maximum gap between successive prime numbers in that interval is 1
    >>> f(2, 12)
    The maximum gap between successive prime numbers in that interval is 3
    >>> f(5, 23)
    The maximum gap between successive prime numbers in that interval is 3
    >>> f(20, 106)
    The maximum gap between successive prime numbers in that interval is 7
    >>> f(31, 291)
    The maximum gap between successive prime numbers in that interval is 13
    '''
    if a <= 0 or b < a:
        sys.exit()
    max_gap = 0
    # Insert your code here
    #如果a,b相等直接输出gap 0
    if a == b:
        print(f"The maximum gap between successive prime numbers in that interval is 0")
    else:
        #如果 a,b不相等，则要把小于a的质数从小于b的质数list中减去
        valid_list = []
        templist = get_primes(b)
        for i in get_primes(b+1):
            if i in get_primes(a):
                templist.remove(i)
        valid_list = templist
        #如果list长度为1，那么就是只有一个元素，直接用输出b-a-1
        if len(valid_list)==1:
            maxgap = b - a -1
            print(f"The maximum gap between successive prime numbers in that interval is {maxgap}")
        else:
            #正常情况，用后一个元素减去前一个
            first = valid_list[0]
            gaplist = []
            for second in valid_list[1:]:
                gaplist.append(second - first -1)
                first = second
            maxgap = max(gaplist)
            print(f"The maximum gap between successive prime numbers in that interval is {maxgap}")
                                       
                                            
    

if __name__ == '__main__':
    import doctest
    doctest.testmod()
